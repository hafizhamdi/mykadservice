Run Installer in admin mode!.

Thank you